db = {
    // 2. 连接 mysql 数据库
    host: "127.0.0.1",
    user: "root",
    password: "tpassword",
    database: "kuaidi", 
  }
  module.exports = db
